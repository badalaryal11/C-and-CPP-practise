#include<stdio.h>
#include<conio.h>
void main()
{
int a;


printf("enter the value of a=\t");
scanf("%d",&a);
switch(a)
{
case 1:
printf("\n no 1 ko batti bolyo");
break;
case 2:
printf("\n no 2 ko batti bolyo");
break;
case 3:
printf("\n no 3 ko batti bolyo");
break;
default:
printf("\ntyesto batti nai xaina");
}
getch();
}
