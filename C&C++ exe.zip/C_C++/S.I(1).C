#include<stdio.h>
#include<conio.h>
void main()
{
	int P,T,R,I;
   printf("Enter the value of P");
   scanf("%d",&P);
   printf("enter the value of T");
   scanf("%d",&T);
   printf("Enter the value of R");
   scanf("%d",&R);
   I= P*T*R/100;
   printf("The simple interest(I)=%d",I);
   getch();
   }
	clrscr();

	int p,t,r,i;
   printf("Enter the values of p,t,r\t")
   scanf("%d","%d","%d",&p,&t,&r);
   I=p*t*r/100;
   printf("The simple interest(I)=%d",I);
   getch();

   }
