#include<stdio.h>
#include<conio.h>
void main()
{
int a,b,c;
	printf("Enter the value of a and b\t");
   scanf("%d""%d",&a,&b);
   c=a+b;
   printf("The sum (c)=\t %d",c);
   if(c>10)
   {
   printf("\n the sum is greater than 10");
   }
   else
   {
   printf("\n the sum is less than 10");
   }
   getch();
   }


