#include<stdio.h>
#include<conio.h>
void main()
{
int a,b;
printf("Enter both the value of a and b=\t");
scanf("%d%d",&a,&b);
if(a<5&&b>32)
{
printf("The number is between 5 and 35");
}
else
{
printf("The number is undifined");
}
getch();
}
