
 age is 19 and name is SUDIKSHYA
 age is 19 and name is BADAL
 age is 17 and name is BARSHA
 age is 19 and name is RABIN
 age is 19 and name is AAKAS
 age is 20 and name is BASANT
 age is 19 and name is BIPLOV
 age is 19 and name is SANDESH
 age is 20 and name is SANJAY
 age is 20 and name is POSHAL
 age is 20 and name is BABLI