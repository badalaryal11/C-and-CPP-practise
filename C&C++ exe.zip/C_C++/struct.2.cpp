#include<stdio.h>
#include<conio.h>
void main
{
for(i=0;
