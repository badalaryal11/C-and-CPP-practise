#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c,d,e;
   printf("Entert the value of a\t");
   scanf("%d",&a);
   printf("Enter the value of b\t");
   scanf("%d",&b);
   c=a+b;
   printf("\tThe sum (s)=%d",c);
   d=a-b;
   printf("\n\tThe difference (d)=%d",d);
   e=a*b;
   printf("\n\tThe multiplication (m)=%d",e);
   getch();
   }
