#include<iostream.h>
#include<conio.h>
void main()
{
	int a,b,c; int marks[5];int i;
   {
   cout<<"Enter the value of a and b"<<endl;
   cin>>a>>b;
   c=a+b;
   cout<<"sum is"<<c<<endl;
   }
   for(i=0;i<5;i++)
   {
   cout<<"HELLO DEAR"<<endl;
   }
   cout<<"Enter the marks";
   for(i=0;i<5;i++)
   {
	cin>>marks[i];
   cout<<"You entred marks"<<marks[i]<<endl;
   }
   getch();
   }

