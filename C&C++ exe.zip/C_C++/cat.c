
The entered value of a is 12
my name is badAL...Aryal and i  am a boy of 19.