#include<stdio.h>
#include<conio.h>
void main()
{
	printf("hello world");
   getch();
   clrscr();
   printf("how are you worid");
   getch();
   }
