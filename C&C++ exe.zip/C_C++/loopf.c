#include<stdio.h>
#include<conio.h>
void main()
{
int i; int j;

for(i=1;i<51;i++)
{
printf("\nHello%d",i);
 }
for(j=1;j<51;j++)
{
printf("\n\t case%d",j);
}
getch();
}





