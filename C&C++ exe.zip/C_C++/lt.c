#include<stdio.h>
#include<conio.h>
void main()
{
int a=100, b=20;
