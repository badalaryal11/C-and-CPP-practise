#include<stdio.h>
#include<conio.h>
void main()
{
int i,j;
for(i=0; i<5; i++)
{
printf("\n hello %d",i);

for(j=0; j<2; j++)
{
printf("\n\tcase %d",j);
}
}
getch();
}