#include<stdio.h>
#include<conio.h>
void main()
{
	printf("\t\t MENU");
   printf("\n\t\t.TEA");
   printf("\n\t\t.COFFEE");
   printf("\n\t\t.MILK");
   printf("\n\t\t.THANKS FOR YOUR VISIT");
   getch();
   }
