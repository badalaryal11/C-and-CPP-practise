#include<stdio.h>
#include<conio.h>
void main()
{
int count;
do
{
printf("\n Hello %d",count);
count=count+1;
}
while(count<101);
getch();
}
