#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c;
	printf("Enter the value of a:\t");
	scanf("%d",&a);
   printf("Enter the value of b:\t");
   scanf("%d",&b);
   c=a+b;
   printf("The sum (c)=\t%d ",c);
   getch();
   }
