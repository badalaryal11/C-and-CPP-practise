#include<stdio.h>
#include<conio.h>
void main()
{
int a=100, b=20;
if(a>10&&b<50)
{
printf("\n test");
}
else
{
printf("\n others");
}
getch();
}
