#include<stdio.h>
#include<conio.h>
void main()
{
char name[11];
printf("Enter ur name:");
scanf("%s",&name);
printf("\n You have entered\t%s",name);
getch();
}
