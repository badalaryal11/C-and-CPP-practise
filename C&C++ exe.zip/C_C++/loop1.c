#include<stdio.h>
#include<conio.h>
void main()
{
   int count;
	while(count<5);
	{
	printf("The no is %d",count);
	count=count+1;
	}
	getch();
   }

