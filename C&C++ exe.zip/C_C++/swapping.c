#include<stdio.h>
#include<conio.h>
void main()
{
int x=10,y=20; int t;
t=x;
x=y;
y=t;
printf("\n x is %d and y is %d",x,y);
getch();
}