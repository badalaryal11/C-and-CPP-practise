#include<stdio.h>
#include<conio.h>
void main()
{
int count;
for(count=0;count<5;count=count+1)
{
printf("\nHello%d",count);
}
getch();
}