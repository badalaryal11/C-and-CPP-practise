#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c;
   printf("Enter the value of a=\t");
   scanf("%d",&a);
   printf("Enter the value of b=\t");
   scanf("%d",&b);
   c=a+b;
   printf("The sum (c)=%d",c);
   if(c>50)
   {
   printf("\n The sum is greater than 50");
   }
   else if (c==50)
   {
   printf("\n The sum is equals to 50");
    }
   else
   {
   printf("\nThe sum is less than 50");
   }
   getch();
   }









































































